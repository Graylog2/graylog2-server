require 'test_helper'

class BlacklistsHelperTest < ActionView::TestCase
end
