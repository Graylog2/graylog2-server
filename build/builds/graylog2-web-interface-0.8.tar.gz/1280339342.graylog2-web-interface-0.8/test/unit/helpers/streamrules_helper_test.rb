require 'test_helper'

class StreamrulesHelperTest < ActionView::TestCase
end
