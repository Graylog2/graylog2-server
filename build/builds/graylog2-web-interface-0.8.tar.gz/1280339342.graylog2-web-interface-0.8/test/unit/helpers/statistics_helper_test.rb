require 'test_helper'

class StatisticsHelperTest < ActionView::TestCase
end
