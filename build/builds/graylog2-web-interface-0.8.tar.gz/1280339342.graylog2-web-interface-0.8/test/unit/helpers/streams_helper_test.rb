require 'test_helper'

class StreamsHelperTest < ActionView::TestCase
end
