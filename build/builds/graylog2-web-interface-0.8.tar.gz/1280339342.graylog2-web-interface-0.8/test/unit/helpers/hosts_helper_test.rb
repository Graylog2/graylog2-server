require 'test_helper'

class HostsHelperTest < ActionView::TestCase
end
