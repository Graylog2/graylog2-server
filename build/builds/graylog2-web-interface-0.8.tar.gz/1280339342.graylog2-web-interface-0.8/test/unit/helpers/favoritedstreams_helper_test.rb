require 'test_helper'

class FavoritedstreamsHelperTest < ActionView::TestCase
end
