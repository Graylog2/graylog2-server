class FavoritedStream < ActiveRecord::Base
  belongs_to :stream
end
