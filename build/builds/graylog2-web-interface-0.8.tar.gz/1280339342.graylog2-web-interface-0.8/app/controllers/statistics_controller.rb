class StatisticsController < ApplicationController
  def index
  end
end
