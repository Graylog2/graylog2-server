class DashboardController < ApplicationController

  layout "dashboard"

  def index
  end

end
